from flask import Flask, render_template, redirect, request, flash, session, url_for, jsonify, g
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import logging
from datetime import datetime
import os
from sqlalchemy.sql.expression import func, desc
from functools import wraps
from flask import abort


app = Flask(__name__)
app.secret_key = "hdsaghiadshihidsgihadsghia"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Set up logging
logging.basicConfig(level=logging.INFO)

# Profile Model
class Profile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(20), unique=True, nullable=False)
    display_name = db.Column(db.String(20), nullable=False)
    pass_word = db.Column(db.String(128), nullable=False)
    avatar = db.Column(db.String(256), nullable=True)  # Field for user avatar
    is_banned = db.Column(db.Boolean, default=False)
    is_admin = db.Column(db.Boolean, default=False)
    followers = db.relationship('Follow', backref='followed', foreign_keys='Follow.followed_id')
    following = db.relationship('Follow', backref='follower', foreign_keys='Follow.follower_id')

    def __init__(self, user_name, display_name, pass_word, avatar=None):
        self.user_name = user_name
        self.display_name = display_name
        self.pass_word = generate_password_hash(pass_word)
        self.avatar = avatar  # Default to None if no avatar provided

class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.relationship('Profile', backref=db.backref('reports', lazy=True))
    postx = db.relationship('Post', backref=db.backref('reports', lazy=True))
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    def __init__(self, user_id, post_id):
        self.user_id = user_id
        self.post_id = post_id

# Follow Model
class Follow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False)
    followed_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False)

    def __init__(self, follower_id, followed_id):
        self.follower_id = follower_id
        self.followed_id = followed_id

class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False)

    def __init__(self, post_id, user_id):
        self.post_id = post_id
        self.user_id = user_id



class Moderation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
   # is_moderated = db.Column(db.Boolean, nullable=False)
    moderation_type = db.Column(db.Integer, nullable=False)
    moderation_reason = db.Column(db.Text, default="Unspecified")
    custom_type = db.Column(db.Text, nullable=True, default="Account Deleted")
    user = db.relationship('Profile', backref=db.backref('moderation', lazy=True))
    expires = db.Column(db.Boolean, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False)
    expires_at = db.Column(db.Integer, nullable=True)
    def __init__(self, moderation_type, moderation_reason, expires, user_id):
        self.moderation_type = moderation_type
        self.expires = expires
       # self.is_moderated = is_moderated
        self.user_id = user_id 
        self.moderation_reason = moderation_reason


# Post Model
class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=db.func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False)
    user = db.relationship('Profile', backref=db.backref('posts', lazy=True))
    likes = db.relationship('Like', backref='post', lazy=True, cascade='all, delete-orphan')

    def __init__(self, title, content, user_id):
        self.title = title
        self.content = content
        self.user_id = user_id

def user_has_liked(likes, username):
    user_profile = Profile.query.filter_by(user_name=username).first()
    if user_profile:
        return any(like.user_id == user_profile.id for like in likes)
    return False

# Register the function as a global Jinja2 function
app.jinja_env.globals['user_has_liked'] = user_has_liked
def length(a):
    return len(a)
app.jinja_env.globals['len']=length
# Initialize database
def initialize_database():
    with app.app_context():  # Add this line to set up the application context
        db.create_all()
        print("Database tables created successfully.")

# Error Handlers
@app.errorhandler(400)
def handle_bad_request(e):
    return render_template("Bad_request.html"), 400

@app.errorhandler(404)
def err404(e):
    return render_template("404.html", url=request.path.replace("/", '')), 404
# Decorator to restrict access to admins
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Ensure the user is logged in and is an admin
        if "user_name" not in session:
            return redirect(url_for('login'))
        
        current_user = Profile.query.filter_by(user_name=session["user_name"]).first()
        if not current_user or not current_user.is_admin and current_user.user_name != "VivaPlaysYT":
            abort(404)  # Forbidden access

        return f(*args, **kwargs)
    return decorated_function
# Index Route
@app.route('/')
def index():
    initialize_database()
    if "user_name" in session:
        return redirect(url_for("user_page", handle=session["user_name"]))
    return render_template("Log_in.html")
@app.before_request
def check_banned():
    # Skip the banned check if the user is accessing the banned page
    print(request.endpoint)
    if request.endpoint == 'banned':
        return None
    if request.endpoint == "logout":
        return None
    if request.endpoint == "clr_warn":
        return None
    # Check if the user is logged in
    if "user_name" in session:
        user = Profile.query.filter_by(user_name=session["user_name"]).first()
        
        # Redirect to banned page if the user is banned
        if user and user.is_banned:  # Assuming `is_banned` is a boolean column in your Profile model
            return redirect(url_for('banned'))

def get_ban_string(ban_type):
    if ban_type == 1:
        return "Account Deleted"
    elif ban_type == 2:
        return "Warning"
    elif ban_type == 3:
        return 3
    elif ban_type == 4:
        return "Banned for 1 Day"
    elif ban_type == 5:
        return "Banned for 1 Week"
    else:
        return False


@app.route('/banned')
def banned():
    if 'user_name' in session:
        user = Profile.query.filter_by(user_name=session["user_name"]).first()

        # Check if the user exists and if they are banned
        
        if user:
            if user.is_banned:  # If the user is banned, render the banned page
                # Get the most recent moderation entry (e.g., by `id` or `expires_at`)
                mod = user.moderation[-1] if user.moderation else None  # Use the last moderation entry

                if mod:  # Ensure there's at least one moderation entry
                    reason = mod.moderation_reason
                    ban_type = mod.moderation_type
                    type_string = get_ban_string(ban_type)
                    if ban_type == 1:
                        return render_template('banned.html', ban_title=type_string, ban_reason=reason)
                    elif ban_type == 2:
                        return render_template('banned.html', ban_title=type_string, ban_reason=reason)
                    elif ban_type == 3:
                        return render_template('banned.html', ban_title=mod.custom_type, ban_reason=reason)
                    elif ban_type == 4:
                        if datetime.now().timestamp() > mod.expires_at:
                            clear_moderation(user.id)
                        else:
                            return render_template('banned.html', ban_title=type_string, ban_reason=reason)
                    elif ban_type == 5:
                        if datetime.now().timestamp() > mod.expires_at:
                            clear_moderation(user.id)
                        else:
                            return render_template('banned.html', ban_title=type_string, ban_reason=reason)
                    else:
                        return render_template('banned.html', ban_title="Account Deleted", ban_reason=reason)
                
                # Fallback if no moderation entry exists
                return render_template('banned.html', ban_title="Account Deleted", ban_reason="No reason specified")
            else:  # If the user is not banned, redirect to home page
                return redirect(url_for('home'))
        else:
            # Handle case where user is not found (optional)
            return redirect(url_for('home'))
    else:
        # If 'user_name' is not in session, redirect to home page or login page
        return redirect(url_for('home'))


def is_admin_user(username):
    user = Profile.query.filter_by(user_name=username).first()
    if user.user_name == "VivaPlaysYT":
        return True
    return user.is_admin
app.jinja_env.globals['is_admin'] = is_admin_user
@app.route('/ban_user/<string:user_handle>/<reason>/<int:typer>/<extra>', methods=['GET'])
@admin_required
def ban_user(user_handle, reason, typer, extra):
    user = Profile.query.filter_by(user_name=user_handle).first()
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if the user is already banned
    if user.is_banned:
        return jsonify({"message": f"User {user_handle} is already banned."}), 400
    
    # Ban the user
    user.is_banned = True
    moderation_entry = Moderation(
        moderation_type=typer,
        moderation_reason=reason,
        expires=False,
        user_id=user.id

    )
    moderation_entry.custom_type = extra
    db.session.add(moderation_entry)
   

    db.session.commit()
    
    return jsonify({"message": f"User {user_handle} has been banned successfully."}), 200

@app.route("/report_post/<int:post_id>", methods=['GET', 'POST'])
def report_post(post_id):
    post = Post.query.filter_by(id=post_id).first_or_404()
    current_user = Profile.query.filter_by(user_name=session['user_name']).first()
    reports_exists = True if current_user.reports else None
    i=0
   
    report_post_exist = False
    for p, rep in enumerate(current_user.reports):

        report_post_exist = True if current_user.reports[p].id == post_id else False
        if report_post_exist:
            i=p
            break
    
    if report_post_exist == False:
        report_entry = Report(
            user_id=current_user.id,
            post_id=post.id 
        )
            
        db.session.add(report_entry)
        db.session.commit()
    else:
        for rep in current_user.reports:
            if rep.post_id == post_id:
                db.session.delete(rep)
        db.session.commit()
        print(current_user.reports)
        
    return redirect(url_for('home'))



@app.route('/clear_warning')
def clr_warn():
    print(session['user_name'])
    if 'user_name' in session:
        user = Profile.query.filter_by(user_name=session["user_name"]).first()
        print(session["user_name"])
        print(user)
        # Check if the user exists and if they are banned
        if user:
            print(user)
            print(user.is_banned)
            if user.is_banned:  # If the user is banned, render the banned page
                # Get the most recent moderation entry (e.g., by `id` or `expires_at`)
                mod = user.moderation[-1] if user.moderation else None  # Use the last moderation entry

                if mod:  # Ensure there's at least one moderation entry
                    
                    reason = mod.moderation_reason
                    ban_type = mod.moderation_type
                    type_string = get_ban_string(ban_type)
                    print(ban_type)
                    if ban_type == 2:
                        user.is_banned = False
                        db.session.delete(mod)
                        db.session.commit()
                        return redirect(url_for('home'))
                    
            else:  # If the user is not banned, redirect to home page
                return redirect(url_for('home'))
        else:
            # Handle case where user is not found (optional)
            return redirect(url_for('home'))
    else:
        # If 'user_name' is not in session, redirect to home page or login page
        return redirect(url_for('home'))

# Like Post Route
@app.route('/like/<int:post_id>', methods=["POST"])
def like_post(post_id):
    initialize_database()
    if "user_name" not in session:
        flash("You need to log in to like posts.", "error")
        return redirect(url_for("login"))

    user = Profile.query.filter_by(user_name=session["user_name"]).first()
    post = Post.query.get_or_404(post_id)

    # Check if the user already liked the post
    existing_like = Like.query.filter_by(post_id=post_id, user_id=user.id).first()
    if existing_like:
        db.session.delete(existing_like)
        flash("Like removed.", "info")
    else:
        new_like = Like(post_id=post_id, user_id=user.id)
        db.session.add(new_like)
        flash("Post liked!", "success")
    
    db.session.commit()
    return redirect(url_for("home"))



# Update User Name Route
@app.route('/update_name', methods=["GET", "POST"])
def update_name():
    initialize_database()

    if "user_name" not in session:
        flash("You need to log in to update your name.", "error")
        return redirect(url_for("login"))

    user = Profile.query.filter_by(user_name=session["user_name"]).first()

    if request.method == "POST":
       
        new_display_name = request.form["name"]

        # Validate input
        if not new_display_name:
            flash("Both username and display name are required.", "error")
            return redirect(url_for("update_name"))

        # Check if new username is taken
       

        # Update the user details
        
        user.display_name = new_display_name

        # Update the session
        
        session["display_name"] = new_display_name

        db.session.commit()

        flash("Username and display name updated successfully!", "success")
        return redirect(url_for("user_page", handle=session['user_name']))

    return render_template("update_name.html", user=user)



@app.route('/delete_post/<int:post_id>', methods=["POST"])
@admin_required
def delete_post(post_id):
    initialize_database()


    # Check if the user is authorized
    

    # Fetch the post to delete
    post = Post.query.get_or_404(post_id)

    # Delete associated likes
    likes_to_delete = Like.query.filter_by(post_id=post.id).all()
    for like in likes_to_delete:
        db.session.delete(like)
    reports_to_delete = Report.query.filter_by(post_id=post.id).all()
    for report in reports_to_delete:
        db.session.delete(report)
    # Delete the post
    db.session.delete(post)
    db.session.commit()

    flash("Post deleted successfully.", "success")
    return redirect(url_for("home"))
@app.route('/edit_profile', methods=["GET", "POST"])
def edit_profile():
    initialize_database()
    
    if "user_name" not in session:
        flash("You need to log in to edit your profile.", "error")
        return redirect(url_for("login"))
    
    user = Profile.query.filter_by(user_name=session["user_name"]).first()
    
    if request.method == "POST":
        display_name = request.form["user_name"]
        avatar = request.form.get("avatar")  # Allow changing avatar
        
        if display_name:
            user.display_name = display_name
        if avatar:
            user.avatar = avatar
        
        db.session.commit()
        flash("Profile updated successfully!", "success")
        return redirect(url_for("user_page", handle=user.user_name))

    return render_template("settings.html", user=user)
# Home Route
@app.route('/home')
def home():
    
    query = request.args.get("sort")
    if not query or query == "default":
        random_posts = Post.query.order_by(func.random()).limit(1000).all()
        return render_template('home.html', posts=random_posts)
    if query == "new":
        recent_posts = Post.query.order_by(Post.created_at.desc()).limit(1000).all()
        return render_template("home.html", posts=recent_posts)

def clear_moderation(user_id):
    # Find all moderation actions for the user
    moderations = Moderation.query.filter_by(user_id=user_id).all()
    user = Profile.query.filter_by(id=user_id).first()
    user.is_banned = False
    if moderations:
        for moderation in moderations:
            db.session.delete(moderation)
        db.session.commit()
        return True  # Successfully cleared moderation
    return False  # No moderation actions to clear


@app.route('/make_admin/<string:user_handle>', methods=['GET', 'POST'])
@admin_required  # Only admins can access this
def make_admin(user_handle):
    # Query the user by their handle
    user = Profile.query.filter_by(user_name=user_handle).first()

    if not user:
        return jsonify({"error": "User not found"}), 404

    # Check if the user is already an admin
    if user.is_admin:
        return jsonify({"message": f"User {user_handle} is already an admin."}), 400

    # Grant admin privileges
    user.is_admin = True
    db.session.commit()

    return jsonify({"message": f"User {user_handle} has been made an admin successfully."}), 200
@app.route('/admin_panel', methods=['GET', 'POST'])
@admin_required
def admin_panel():
    mt=0
    isadmin = Profile.query.filter_by(user_name=session['user_name']).first().is_admin

    if not isadmin and session['user_name'] != "VivaPlaysYT":
        return redirect(url_for("index")) 

    users = Profile.query.all()

    if request.method == 'POST':
        action = request.form.get('action')
        user_id = request.form.get('user_id')
       

        user = Profile.query.filter_by(id=user_id).first()
        pst = None
        if request.args.get('type') == 'posts':
            pst = Post.query.filter_by(id=user_id).first()
        if not user:
            flash("User not found.", "danger")
            return redirect(url_for('admin_panel'))

        if action == 'ban':
            user.is_banned = True
            moderation_entry = Moderation(
                moderation_type=1,
                moderation_reason="No reason specified.",
                expires=False,
                user_id=user.id

            )
            
            db.session.add(moderation_entry)
            
            flash(f"User {user.user_name} has been banned.", "success")
        elif action == 'unban':
            user.is_banned = False
            clear_moderation(user.id)
            flash(f"User {user.user_name} has been unbanned.", "success")
        elif action == 'make_admin':
            user.is_admin = True
            flash(f"User {user.user_name} is now an admin.", "success")
        elif action == 'remove_admin':
            user.is_admin = False
            flash(f"User {user.user_name} is no longer an admin.", "success")
        elif action == "wipe_user":
            # Delete all likes associated with the user's posts
            likes_to_delete = Like.query.filter_by(user_id=user.id).all()
            
            for like in likes_to_delete:
                db.session.delete(like)
            
            followers_to_delete = Follow.query.filter_by(follower_id=user.id).all()
            followed_to_delete = Follow.query.filter_by(followed_id=user.id).all()
            for follow in followers_to_delete:
                db.session.delete(follow)
            for follower in followed_to_delete:
                db.session.delete(follower)

            # Delete all posts by this user
            posts_to_delete = Post.query.filter_by(user_id=user.id).all()
            st = "Wiped" + str(datetime.now().timestamp()) + str(user.id)
            logout_user(user.user_name)
            user.user_name = st
            user.is_banned = True
            moderation_entry = Moderation(
                moderation_type=2,
                moderation_reason="No reason specified.",
                expires=False,
                user_id=user.id

            )
            db.session.add(moderation_entry)
            for post in posts_to_delete:
                db.session.delete(post)
        elif action == "wipe_ban":
            # Delete all likes associated with the user's posts
            likes_to_delete = Like.query.filter_by(user_id=user.id).all()
            
            for like in likes_to_delete:
                db.session.delete(like)
            
            followers_to_delete = Follow.query.filter_by(follower_id=user.id).all()
            followed_to_delete = Follow.query.filter_by(followed_id=user.id).all()
            for follow in followers_to_delete:
                db.session.delete(follow)
            for follower in followed_to_delete:
                db.session.delete(follower)

            # Delete all posts by this user
            posts_to_delete = Post.query.filter_by(user_id=user.id).all()
            
            for post in posts_to_delete:
                db.session.delete(post)
            user.is_banned = True
            moderation_entry = Moderation(
                moderation_type=3,
                moderation_reason="No reason specified.",
                expires=False,
                user_id=user.id

            )
           # user.user_name = "Wiped" + str(datetime.now().timestamp()) + str(user.id)
            moderation_entry.custom_type = "Account Wiped and Deleted"
            db.session.add(moderation_entry)
        elif action == 'warn':
            user.is_banned = True
            moderation_entry = Moderation(
                moderation_type=2,
                moderation_reason="No reason specified.",
                expires=False,
                user_id=user.id

            )
            db.session.add(moderation_entry)
        elif action=="1day":
            user.is_banned = True
            moderation_entry = Moderation(
                moderation_type=4,
                moderation_reason="No reason specified.",
                expires=False,
                user_id=user.id

            )
            moderation_entry.expires = True
            moderation_entry.expires_at = datetime.now().timestamp()+86400
            db.session.add(moderation_entry)
        elif action=="7day":
            user.is_banned = True
            moderation_entry = Moderation(
                moderation_type=5,
                moderation_reason="No reason specified.",
                expires=False,
                user_id=user.id

            )
            moderation_entry.expires = True
            moderation_entry.expires_at = datetime.now().timestamp()+604800
            db.session.add(moderation_entry)
        elif action=="delete_user":
            profile = Profile.query.filter_by(id=user_id).delete()
            
        elif action == 'delete_post':
            delete_post(pst.id)
            mt=1
        else:
            flash("Invalid action.", "danger")

        db.session.commit()
        return redirect(url_for('admin_panel'))
    
    if request.args.get('type') == 'posts':
        mt=1
    print(mt)
    posts_ordered_by_reports = (
        db.session.query(Post)
            .outerjoin(Report, Post.id == Report.post_id)  # Outer join to include posts with no reports
            .group_by(Post.id)
            .order_by(desc(func.count(Report.id)))  # Order by report count in descending order
            .all()
    )
    return render_template('admin_panel.html', users=users, posts=posts_ordered_by_reports, mth=mt)

def logout_user(username):
    user_session = session.get(username)
    if user_session:
        session.pop(username, None)  # Remove specific user from session

@app.route('/create_post', methods=["GET", "POST"])
def create_post():
    initialize_database()
    session.pop('_flashes', None)
    if "user_name" not in session:
        
        flash("You need to log in to create a post.", "error")
        return redirect(url_for("login"))
    
    if request.method == "POST":
        title = request.form["title"]
        content = request.form["content"]
        user_name = session["user_name"]
        

        user = Profile.query.filter_by(user_name=user_name).first()

        new_post = Post(title=title, content=content, user_id=user.id)
        db.session.add(new_post)
        db.session.commit()

        flash("Post created successfully!", "success")
        return redirect(url_for("user_page", handle=user_name))

    return render_template("create_post.html")

@app.route('/delete_posts/<user_name>', methods=["GET","POST"])
@admin_required
def delete_all_posts(user_name):
    initialize_database()

    if "user_name" not in session:
        flash("You need to log in to perform this action.", "error")
        return redirect(url_for("login"))

    # Check if the logged-in user matches the user requesting the deletion
   
   
    # Find the user by username
    user = Profile.query.filter_by(user_name=user_name).first()
    
    if not user:
        flash("User not found!", "error")
        return redirect(url_for("home"))

    # Delete all likes associated with the user's posts
    likes_to_delete = Like.query.filter_by(user_id=user.id).all()
    
    for like in likes_to_delete:
        db.session.delete(like)

    # Delete all posts by this user
    posts_to_delete = Post.query.filter_by(user_id=user.id).all()
    
    for post in posts_to_delete:
        db.session.delete(post)
    user.is_banned = True
    db.session.commit()
    flash("All posts and likes deleted successfully.", "success")

    return redirect(url_for("user_page", handle=user_name))




# Login Route
@app.route('/login', methods=["GET", "POST"])
def login():
    initialize_database()
    if request.method == "POST":
        user_name = request.form.get("handle")
        pass_word = request.form.get("pass_word")

        user = Profile.query.filter_by(user_name=user_name).first()

        if user and check_password_hash(user.pass_word, pass_word):
            session["user_name"] = user.user_name
            session['user_id'] = user.id
            session["display_name"] = user.display_name
            flash("Logged in successfully!", "success")
            return redirect(url_for("user_page", handle=user.user_name))
        else:
            print("invalid user or pass!")
            flash("Invalid username or password!", "error")
            return redirect(url_for("login"))
    return render_template("Log_in.html")

# Logout Route
@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully!", "success")
    return redirect(url_for("index"))

# Register Route
@app.route('/register', methods=["GET", "POST"])
def register():
    initialize_database()
    if request.method == "POST":
        user_name = request.form["handle"]
        display_name = request.form["user_name"]
        pass_word = request.form["pass_word"]
        avatar = request.form.get("avatar")  # Avatar URL or path if provided

        if not user_name or not display_name or not pass_word:
            flash("All fields are required!", "error")
            return redirect(url_for("register"))

        if Profile.query.filter_by(user_name=user_name).first():
            flash("Username already exists!", "error")
            return redirect(url_for("register"))

        new_user = Profile(user_name=user_name, display_name=display_name, pass_word=pass_word, avatar=avatar)
        db.session.add(new_user)
        db.session.commit()

        flash("Registration successful! You can now log in.", "success")
        return redirect(url_for("login"))
    return render_template("signup.html")
    
@app.route("/delete_user/<handle>")
@admin_required
def delusr(handle):
    initialize_database()

    if "user_name" not in session:
        flash("You need to log in to perform this action.", "error")
        return redirect(url_for("login"))

    # Check if the logged-in user matches the user requesting the deletion
   
   
    # Find the user by username
    user = Profile.query.filter_by(user_name=handle).first()
    
    if not user:
        flash("User not found!", "error")
        return redirect(url_for("home"))

    # Delete all likes associated with the user's posts
    likes_to_delete = Like.query.filter_by(user_id=user.id).all()
    
    for like in likes_to_delete:
        db.session.delete(like)

    # Delete all posts by this user
    posts_to_delete = Post.query.filter_by(user_id=user.id).all()
    
    for post in posts_to_delete:
        db.session.delete(post)
    profile = Profile.query.filter_by(user_name=handle).delete()
    
    db.session.commit()
    return redirect("/users/" + handle)
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query')
    if not query:
        flash("Please enter a search term.", "error")
        return redirect(url_for("home"))
    
    # Search for profiles with a matching username or display name
    profiles = Profile.query.filter(
        (Profile.user_name.like(f"%{query}%")) | 
        (Profile.display_name.like(f"%{query}%"))
    ).all()

    # Search for posts with a matching title or content
    posts = Post.query.filter(
        (Post.title.like(f"%{query}%")) | 
        (Post.content.like(f"%{query}%"))
    ).all()

    return render_template("search_results.html", query=query, profiles=profiles, posts=posts)
# User Profile Route
@app.route('/users/<handle>')
def user_page(handle):
    initialize_database()
    if "user_name" not in session:
        flash("You need to log in to view this page.", "error")
        return redirect(url_for("login"))
    
    profile = Profile.query.filter_by(user_name=handle).first()
    if not profile or profile.is_banned == True:
        return render_template("404.html", url=handle), 404

    # Get followers and following count
    followers_count = Follow.query.filter_by(followed_id=profile.id).count()
    following_count = Follow.query.filter_by(follower_id=profile.id).count()

    # Check if the logged-in user is following the profile
    is_following = Follow.query.filter_by(follower_id=session['user_id'], followed_id=profile.id).first() is not None

    # Default to "none" for avatar if not set
    avatar_url = profile.avatar if profile.avatar else "none"

    return render_template("User.html", name=profile.display_name, avatar=avatar_url, id=profile.id, handle=handle, posts=profile.posts, followers_count=followers_count, following_count=following_count, is_following=is_following)

@app.route('/increase_followers/<string:user_name>/<int:number>', methods=["GET"])
@admin_required
def increase_followers(user_name, number):
    initialize_database()

    if "user_name" not in session:
        flash("You need to log in to perform this action.", "error")
        return redirect(url_for("login"))

    logged_in_user = Profile.query.filter_by(user_name=session["user_name"]).first()

    # Get the user for whom the followers count is to be increased using the username
    user_to_increase = Profile.query.filter_by(user_name=user_name).first()
    if not user_to_increase:
        flash("User not found!", "error")
        return redirect(url_for("home"))

    for _ in range(number):
        # Create fake follow relationships where the logged-in user is the follower
        new_follow = Follow(follower_id=user_to_increase.id, followed_id=user_to_increase.id)
        db.session.add(new_follow)

    db.session.commit()
    flash(f"Successfully increased followers count for {user_to_increase.user_name} by {number}.", "success")
    
    # After modifying, redirect back to the user's profile page
    return redirect(url_for("user_page", handle=user_to_increase.user_name))

# Follow/Unfollow Route
@app.route('/follow/<int:user_id>', methods=["POST"])
def follow_user(user_id):
    initialize_database()

    if "user_name" not in session:
        flash("You need to log in to follow users.", "error")
        return redirect(url_for("login"))

    logged_in_user = Profile.query.filter_by(user_name=session["user_name"]).first()
    
    # Check if the user is already following
    follow_relation = Follow.query.filter_by(follower_id=logged_in_user.id, followed_id=user_id).first()
    
    if follow_relation:
        db.session.delete(follow_relation)
        flash("Unfollowed the user.", "info")
    else:
        new_follow = Follow(follower_id=logged_in_user.id, followed_id=user_id)
        db.session.add(new_follow)
        flash("Followed the user.", "success")
    
    db.session.commit()
    return redirect(url_for("user_page", handle=logged_in_user.user_name))
if __name__ == "__main__":
    initialize_database()
    app.run(host='0.0.0.0', port=81)
